if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@transformer
def transform(data, *args, **kwargs):
 
    # Remove rows where passenger count is 0 and trip distance is 0
    data = data[(data['passenger_count'] > 0) & (data['trip_distance'] > 0)]

    # Create a new column lpep_pickup_date
    data['lpep_pickup_date'] = data['lpep_pickup_datetime'].dt.date

    # Rename columns in Camel Case to Snake Case
    data = data.rename(columns={
        'VendorID': 'vendor_id',
        'store_and_fwd_flag': 'store_and_fwd_flag',
        'RatecodeID': 'ratecode_id',
        'PULocationID': 'pu_location_id',
        'DOLocationID': 'do_location_id',
        'passenger_count': 'passenger_count',
        'trip_distance': 'trip_distance',
        'fare_amount': 'fare_amount',
        'extra': 'extra',
        'mta_tax': 'mta_tax',
        'tip_amount': 'tip_amount',
        'tolls_amount': 'tolls_amount',
        'ehail_fee': 'ehail_fee',
        'improvement_surcharge': 'improvement_surcharge',
        'total_amount': 'total_amount',
        'payment_type': 'payment_type',
        'trip_type': 'trip_type',
        'congestion_surcharge': 'congestion_surcharge',
        'lpep_pickup_datetime': 'lpep_pickup_datetime',
        'lpep_dropoff_datetime': 'lpep_dropoff_datetime',
        'lpep_pickup_date': 'lpep_pickup_date'
    })

    # Assertions
    assert data['vendor_id'].isin([1, 2]).all(), 'Assertion Error: vendor_id is not one of the existing values'
    assert (data['passenger_count'] > 0).all(), 'Assertion Error: passenger_count is not greater than 0'
    assert (data['trip_distance'] > 0).all(), 'Assertion Error: trip_distance is not greater than 0'

    return data


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'
